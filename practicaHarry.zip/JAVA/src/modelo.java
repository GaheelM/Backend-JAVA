public class modelo {

    public String casa;
    public String genero;
    public String nombre;
    public String boggart;
    public String patronus;



    /**Modelado de getters **/
    public String getCasa(){
        return casa;
    }

    public String getGenero(){
        return genero;
    }

    public String getNombre(){
        return nombre;
    }

    public String getBoggart(){
        return boggart;
    }

    public String getPatronus(){
        return patronus;
    }


    /** Modelado de setters **/
    public void setCasa(String casa){
        this.casa = casa;
    }

    public void setGenero(String genero){
        this.genero = genero;
    }

    public void setNombre(String nombre){ this.nombre = nombre; }

    public void setbBoggart(String boggart){
        this.boggart = boggart;
    }

    public void setPatronus(String patronus){
        this.patronus = patronus;
    }


    /** Modelado de personajes con constructor**/
    public modelo(String _nombre, String _genero, String _casa, String _boggart, String _patronus ){
        nombre = _nombre;
        genero = _genero;
        casa = _casa;
        boggart = _boggart;
        patronus = _patronus;
    }

    public void mostrarpersonaje(){
        System.out.println("Personaje: "+ nombre);
        System.out.println("Genero: "+ genero);
        System.out.println("Casa: "+ casa);
        System.out.println("Boggart: "+ boggart);
        System.out.println("Patronus: "+ patronus);
    }


}
