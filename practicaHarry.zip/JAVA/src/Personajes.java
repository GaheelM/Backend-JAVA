import java.security.spec.RSAOtherPrimeInfo;

public class Personajes {
    public static void main(String[] args){
        modelo personajes = new modelo("Harry James Potter", "Masculino","Gryffindor"
       , "Dementor","Ciervo");

        personajes.mostrarpersonaje();
    }
}
